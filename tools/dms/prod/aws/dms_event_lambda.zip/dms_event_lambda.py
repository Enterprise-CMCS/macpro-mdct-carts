import json

def handler(event, context):
    print(event['Records'][0]['Sns']['Message'])