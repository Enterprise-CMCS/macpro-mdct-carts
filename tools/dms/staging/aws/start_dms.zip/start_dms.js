const zlib = require('zlib');
const AWS = require('aws-sdk');
const { Client } = require('pg');
const DEBUG = false;
const DEBUG_SECRETS = false;

const parseEvents = (event) => {
    if (event.awslogs && event.awslogs.data) {
        const payload = Buffer.from(event.awslogs.data, 'base64');
        DEBUG && console.log('payload', payload);
        const logevents = JSON.parse(zlib.unzipSync(payload).toString()).logEvents;
        return logevents;
    }
};

const outputLogEvents = (events) => {
    if(DEBUG) {
        for (const logevent of events) {
            const log = JSON.parse(logevent.message);
            console.log('Event Message', log);
        }
    }
};

const inferReplicationSuccessStatus = (events) => {
      let lastEventMessage = JSON.parse(events[events.length-1].message);
      let eventMessage = lastEventMessage['Event Message'];
      return eventMessage.search('FULL_LOAD_ONLY_FINISHED') > -1;
};

const issueQuery = (username, password, databasename, hostname, port = 5432) => {
    DEBUG && console.log('user:', username, 'pass:', DEBUG_SECRETS && password || 'MASKED', 'databasename:', databasename, 'host:', hostname, 'port:', port);

    const client = new Client({
        user: username,
        host: hostname,
        database: databasename,
        password: password,
        port: port,
    });
    client.connect();
    client.query('select perform_migrate_section_2(2020)', (err, resp) => {
        console.log('Callback:', err, resp);
        client.end();
    });
}

const executeTask = () => {
    let ssm = new AWS.SSM({region: 'us-east-1'});

    let ssmParameters = {
        '/staging/postgres_db': null,
        '/staging/postgres_host': null,
        '/staging/postgres_password': null,
        '/staging/postgres_user': null
    };

    let params = {
        Names: Object.keys(ssmParameters),
        WithDecryption: true
    };
    return ssm.getParameters(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else {
            data.Parameters.forEach((item) => {
                //console.log(item);
                let value = item.Value;
                let name = item.Name;
                ssmParameters[name] = value;
            });
            DEBUG && DEBUG_SECRETS && console.log('Secrets:',JSON.stringify(ssmParameters));

            issueQuery(
                ssmParameters['/staging/postgres_user'],
                ssmParameters['/staging/postgres_password'],
                ssmParameters['/staging/postgres_db'],
                ssmParameters['/staging/postgres_host']
            );
        }
    });
};

exports.handler = async (event, context, callback) => {
    let events = parseEvents(event);
    outputLogEvents(events);
    let wasReplicationSuccessful = inferReplicationSuccessStatus(events);
    DEBUG && console.log('Was replication successful?', wasReplicationSuccessful);
    if(wasReplicationSuccessful) {
        executeTask();
        callback(null, 'Translation successfully executed');
    } else callback(null, 'Translation failed');
};
