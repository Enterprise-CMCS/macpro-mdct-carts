import json


def handler(event, context):
    print("New DMS Task starts...")
